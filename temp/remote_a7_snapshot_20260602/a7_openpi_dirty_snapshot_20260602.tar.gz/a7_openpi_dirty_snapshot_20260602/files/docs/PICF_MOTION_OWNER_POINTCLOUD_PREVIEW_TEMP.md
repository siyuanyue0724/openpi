# PICF Motion-Owner Pointcloud Preview TEMP

Status: diagnostic sidecar only. This file documents the dataflow and math for
`scripts/picf_motion_owner_preview.py`.

## Goal

We need to inspect whether CALVIN RGB-D motion provides a usable weak signal for
object binding.  The preview separates sampled static-camera RGB-D points into:

- gray: static or below motion threshold;
- orange: robot / end-effector-like moving points;
- palette colors: non-robot coherent moving clusters, i.e. candidate manipulated
  objects.
- red rings: prompt-color target seed, e.g. the visible "red block" before it
  has started moving.

This is not a training target yet.  It is an evidence-quality audit before any
motion-owner loss is attached to AQR anchors.

## Dataflow

For a language segment and frame pair `(t, t + d)`:

1. Load `rgb_static_t`, `depth_static_t`, `robot_obs_t` and the next-frame
   counterparts from CALVIN.
2. Load static camera intrinsics/extrinsics from `calib/cameras.json` through
   `CalvinDepthToPicfPointCloud`, so the preview uses the same camera
   calibration path as PICF point cloud construction.
3. Sample valid depth pixels on a stride grid and unproject both frames to
   static-camera world point clouds.
4. Match frame-`t` points to frame-`t+d` by nearest neighbor in world coordinates
   and use nearest-neighbor distance as a pointcloud occupancy-change signal.
   This is the default because it avoids coloring static background through
   optical-flow leakage at object/robot boundaries:

   ```text
   X_t       = W_T_C K^-1 [u_t, v_t, 1]^T depth_t(u_t, v_t)
   NN(X_t)   = argmin_{Y in P_{t+d}} ||X_t - Y||
   delta_occ = ||X_t - NN(X_t)||
   ```

   The script still exposes `--correspondence-mode flow` for debugging, but the
   flow mode is not the recommended sidecar source.
5. Use `EndEffectorLocalFrame.make_transform(robot_obs)` for `G_t` and
   `G_{t+d}`.  The translational components give the end-effector centers
   `e_t`, `e_{t+d}`.
6. Segment moving points into piecewise-rigid bodies by sequential RANSAC and
   Kabsch SE(3) fitting:

   ```text
   X' ≈ R_k X + t_k
   residual_i(k) = ||R_k X_i + t_k - X'_i||
   body_k = {i | residual_i(k) < eps}
   ```

   This is the core grouping step.  It follows the standard rigid-motion
   assumption behind RGB-D scene-flow / multi-body segmentation: background is
   identity-like, the manipulated object is rigid, and robot links are also
   piecewise rigid even though the full arm is articulated.
7. Classify robot-like rigid bodies with three seeds:

   ```text
   robot_core = min(||X_t - e_t||, ||X_{t+d} - e_{t+d}||) <= r_core
   robot_sweep = dist(X_t, segment(e_t, e_{t+d})) <= r_sweep
   direction_ok = cos(m_t, e_{t+d} - e_t) >= c_min
   robot_seed = robot_core | (robot_sweep & direction_ok)
   robot_color = low-saturation gray/white or dark gripper material
   robot_component =
     any(robot_seed) OR robot_color_fraction high OR near projected EE pixel
   ```

8. Remaining rigid bodies are rendered as candidate manipulated objects.  A
   contact event can merge the gripper and object in image space, so the script
   also keeps high-saturation moving surfaces outside the end-effector core as
   object candidates.  This is an appearance-motion split, not a semantic label.

## Mathematical Boundary

This diagnostic estimates a weak partition:

```text
Z_t = Z_static ∪ Z_robot ∪ Z_nonrobot_motion
```

It is useful because a manipulated object should often be a coherent non-robot
rigid body near a contact event.  It is not a perfect object label:

- optical flow can fail on specular, textureless, or occluded regions;
- robot-link ownership still needs kinematic priors because CALVIN does not
  expose a full per-link robot mesh label in this sidecar;
- robot mesh segmentation is only approximated by end-effector geometry;
- static but task-relevant objects, such as a button before contact, may remain
  gray unless they match the explicit language-color seed.

The language-color seed is diagnostic only.  It should be interpreted as an
appearance target prior, not motion ownership.  The useful future supervision
signal is the agreement between this target seed, contact/robot approach, and
later non-robot rigid-body motion.

Therefore the output should be used first as an audit/sidecar signal.  A future
loss, if added, should be gated by cluster confidence, temporal consistency, and
agreement with point/contact/PG support.  It must not overwrite posterior belief
as hard truth.

## Expected Use

Run a few segments:

```bash
PYTHONPATH=src uv run python scripts/picf_motion_owner_preview.py \
  --calvin-root /mnt/calvin_data/task_ABC_D \
  --backend dir \
  --split training \
  --segment-indices 9454,6279,16980 \
  --frames 24 \
  --frame-gap 2 \
  --output-root /mnt/picf_motion_owner_previews/$(date +%Y%m%d_%H%M%S)
```

Inspect:

- whether orange follows the gripper/robot;
- whether colored non-robot clusters align with the pushed/lifted/moved object;
- whether static background remains gray;
- whether cluster statistics are stable enough to become a weak sidecar.
