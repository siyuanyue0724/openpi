#!/usr/bin/env bash
set -euo pipefail
cd /root/openpi_posterior_vla_clean
export UV_PROJECT_ENVIRONMENT=/root/openpi/.venv
export PYTHONPATH=/root/openpi_posterior_vla_clean/src
export CUDA_VISIBLE_DEVICES=0,1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export TORCH_NCCL_ASYNC_ERROR_HANDLING=1
/root/.local/bin/uv run --no-sync torchrun --standalone --nnodes=1 --nproc_per_node=2 scripts/picf_core_train.py \
  --calvin-root /mnt/calvin_data/task_ABC_D \
  --backend dir \
  --checkpoint-base-dir /mnt/checkpoints/picf_core \
  --exp-name picf_mvtrack_anchor_only_acc4_lr5e4_probe200_20260510_202225 \
  --overwrite \
  --device cuda \
  --use-foundation-backbones \
  --perception-finetune-mode frozen \
  --picf-trainable-scope anchor_only \
  --training-strategy fsdp_full_shard \
  --optimizer-sharding none \
  --accum-steps 4 \
  --unroll-steps 1 \
  --burnin-steps 0 \
  --action-horizon 16 \
  --semantic-max-length 256 \
  --visual-feature-mode hierarchical \
  --visual-checkpoint-path /root/openpi/checkpoints/foundation/vjepa2_1/vjepa2_1_vit_base_384/vjepa2_1_vitb_dist_vitG_384.pt \
  --tactile-checkpoint-path /root/openpi/checkpoints/foundation/anytouch2/checkpoint-4frames.pth \
  --tactile-calibration-path /mnt/checkpoints/picf_core/debug/tactile_calib_task_ABC_D_rgb_latent_full_v8/tactile_fingertip_calibration.json \
  --tactile-backgrounds-path /mnt/checkpoints/picf_core/debug/tactile_calib_task_ABC_D_rgb_latent_full_v8/tactile_backgrounds.npz \
  --tactile-contact-stats-path /mnt/checkpoints/picf_core/debug/tactile_calib_task_ABC_D_rgb_latent_full_v8/tactile_contact_stats.json \
  --sonata-checkpoint-path /root/openpi/src/pretrain/SpatialLM_Sonata_encoder.pth \
  --semantic-checkpoint-path /mnt/checkpoints/pi05_base_pytorch \
  --action-normalization quantile \
  --action-norm-stats-path /root/openpi_posterior_vla_clean/assets/pi05_calvin_sonata/calvin/norm_stats.json \
  --prompt-state-normalization inherit \
  --prompt-state-norm-stats-path /root/openpi_posterior_vla_clean/assets/pi05_calvin_sonata/calvin/norm_stats.json \
  --num-train-steps 200 \
  --lr 0.0005 \
  --min-lr 0.00005 \
  --warmup-steps 20 \
  --save-interval 50 \
  --keep-last-checkpoints 3 \
  --log-interval 5 \
  --diagnostic-interval 0 \
  --grad-clip-mode percentile \
  --grad-clip-percentile 75 \
  --grad-clip-window 100 \
  --wandb-mode disabled \
  --no-wandb
