#!/usr/bin/env bash
set -euo pipefail
cd /root/openpi_posterior_vla_clean
WAIT_SESSION=${WAIT_SESSION:-picf_a7_lifecycle_phasea_20260515}
EXP=picf_a7_diag_nontruncated_signature_u2b1_180_20260515
LOG=/mnt/picf_run_logs/${EXP}_queued.log
mkdir -p /mnt/picf_run_logs
{
  echo "queued_at=$(date -Iseconds) waiting_for=${WAIT_SESSION}"
  while tmux has-session -t "${WAIT_SESSION}" 2>/dev/null; do
    echo "$(date -Iseconds) still_waiting_for=${WAIT_SESSION}"
    sleep 60
  done
  echo "$(date -Iseconds) starting_signature_dump_diagnostic"
  ./run_a7_nontruncated_signature_probe_diagnostic_20260515.sh
  echo "$(date -Iseconds) running_quadratic_overlay_probe"
  ./run_a7_nontruncated_signature_probe_post_20260515.sh | tee /mnt/picf_run_logs/${EXP}_probe.log
  echo "$(date -Iseconds) done"
} 2>&1 | tee "$LOG"
