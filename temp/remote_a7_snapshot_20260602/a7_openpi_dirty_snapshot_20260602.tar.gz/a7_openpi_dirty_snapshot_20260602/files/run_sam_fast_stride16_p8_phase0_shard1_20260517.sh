#!/usr/bin/env bash
set -euo pipefail
cd /root/openpi_posterior_vla_clean
export PYTHONPATH=/tmp/picf_sam_code/segment-anything:/root/openpi_posterior_vla_clean/src:${PYTHONPATH:-}
export CUDA_VISIBLE_DEVICES=1
python scripts/picf_sam_proposal_precompute.py \
  --calvin-root /mnt/calvin_data/task_ABC_D \
  --backend dir \
  --split training \
  --output-root /mnt/picf_sidecars/sam_proposals_vitb_stride16_p8_phase0_20260517 \
  --views both \
  --shard-index 1 --num-shards 4 \
  --frame-stride 16 --frame-offset 0 \
  --sam-checkpoint /mnt/picf_sidecars/sam_ckpts/sam_vit_b_01ec64.pth \
  --sam-model-type vit_b \
  --device cuda \
  --points-per-side 8 \
  --max-proposals-per-view 32 \
  --log-every 50 \
  --skip-existing
